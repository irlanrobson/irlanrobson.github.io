//--------------------------------------------------------------------------------------------------
/*
	@file		b3DistanceJoint.cpp

	@author		Irlan Robson
	@version	0.1
	@date		20/02/2016

	Copyright(C) 2016 by I. Robson. All rights reserved.
*/
//--------------------------------------------------------------------------------------------------

#include "b3DistanceJoint.h"
#include "..\b3Body.h"
#include "..\..\Common\b3Draw.h"

b3DistanceJoint::b3DistanceJoint(const b3DistanceJointDef* def) 
{
	m_type = e_distanceJoint;
	m_bodyA = def->bodyA;
	m_bodyB = def->bodyB;
	m_userData = def->userData;
	m_localAnchorA = def->localAnchorA;
	m_localAnchorB = def->localAnchorB;
	m_length = def->length;
	m_impulse = 0.0f;
}

void b3DistanceJoint::InitializeConstraints(const b3SolverData* data) 
{
	m_indexA = m_bodyA->m_islandID;
	m_indexB = m_bodyB->m_islandID;

	m_mA = m_bodyA->m_invMass;
	m_mB = m_bodyB->m_invMass;

	m_iA = m_bodyA->m_invWorldInertia;
	m_iB = m_bodyB->m_invWorldInertia;

	m_localCenterA = m_bodyA->m_localCenter;
	m_localCenterB = m_bodyB->m_localCenter;

	b3Vec3 xA = data->positions[m_indexA].x;
	b3Quaternion qA = data->positions[m_indexA].q;
	b3Vec3 xB = data->positions[m_indexB].x;
	b3Quaternion qB = data->positions[m_indexB].q;

	// Jacobian
	b3Vec3 rA = b3Mul(qA, m_localAnchorA - m_localCenterA);
	b3Vec3 rB = b3Mul(qB, m_localAnchorB - m_localCenterB);

	b3Vec3 d = xB + rB - xA - rA;
	
	r32 length = b3Len(d);
	
	b3Vec3 n;
	n.SetZero();
	if (length > 0.0f)
	{
		n = (1.0f / length) * d;
	}

	m_J.linearA = -n;
	m_J.angularA = -b3Cross(rA, n);
	m_J.linearB = n;
	m_J.angularB = b3Cross(rB, n);

	// Inverse Mass Matrix
	b3Mat33 MA = b3Diagonal(m_mA);
	b3Mat33 MB = b3Diagonal(m_mB);

	r32 kMass = 
		b3Mul1x3w3x1(b3Mul1x3w3x3(m_J.linearA, MA), m_J.linearA) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(m_J.angularA, m_iA), m_J.angularA) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(m_J.linearB, MB), m_J.linearB) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(m_J.angularB, m_iB), m_J.angularB);

	// Singularity is handled automatically
	m_mass = kMass != 0.0f ? 1.0f / kMass : 0.0f;
}

void b3DistanceJoint::WarmStart(const b3SolverData* data) 
{
	data->velocities[m_indexA].v += m_mA * m_impulse * m_J.linearA;
	data->velocities[m_indexA].w += b3Mul(m_iA, m_impulse * m_J.angularA);
	data->velocities[m_indexB].v += m_mB * m_impulse * m_J.linearB;
	data->velocities[m_indexB].w += b3Mul(m_iB, m_impulse * m_J.angularB);
}

void b3DistanceJoint::SolveVelocityConstraints(const b3SolverData* data) 
{
	b3Vec3 vA = data->velocities[m_indexA].v;
	b3Vec3 wA = data->velocities[m_indexA].w;
	b3Vec3 vB = data->velocities[m_indexB].v;
	b3Vec3 wB = data->velocities[m_indexB].w;

	r32 Cdot = b3Dot(m_J.linearA, vA) + b3Dot(m_J.angularA, wA) + b3Dot(m_J.linearB, vB) + b3Dot(m_J.angularB, wB);
	r32 lambda = -m_mass * Cdot;

	m_impulse += lambda;
	
	vA += m_mA * lambda * m_J.linearA;
	wA += b3Mul(m_iA, lambda * m_J.angularA);
	vB += m_mB * lambda * m_J.linearB;
	wB += b3Mul(m_iB, lambda * m_J.angularB);

	data->velocities[m_indexA].v = vA;
	data->velocities[m_indexA].w = wA;
	data->velocities[m_indexB].v = vB;
	data->velocities[m_indexB].w = wB;
}

bool b3DistanceJoint::SolvePositionConstraints(const b3SolverData* data) 
{
	b3Vec3 xA = data->positions[m_indexA].x;
	b3Quaternion qA = data->positions[m_indexA].q;
	b3Vec3 xB = data->positions[m_indexB].x;
	b3Quaternion qB = data->positions[m_indexB].q;

	// Jacobian
	b3Vec3 rA = b3Mul(qA, m_localAnchorA - m_localCenterA);
	b3Vec3 rB = b3Mul(qB, m_localAnchorB - m_localCenterB);
	
	b3Vec3 d = xB + rB - xA - rA;
	r32 length = b3Len(d);
	r32 C = length - m_length;
	
	b3Vec3 n;
	n.SetZero();
	if (length > 0.0f)
	{
		n = (1.0f / length) * d;
	}

	r32 linearError = b3Abs(C);
	
	b3Jacobian J;
	J.linearA = -n;
	J.angularA = -b3Cross(rA, n);
	J.linearB = n;
	J.angularB = b3Cross(rB, n);

	// Inverse Mass Matrix
	b3Mat33 MA = b3Diagonal(m_mA);
	b3Mat33 MB = b3Diagonal(m_mB);

	r32 kMass =
		b3Mul1x3w3x1(b3Mul1x3w3x3(J.linearA, MA), J.linearA) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(J.angularA, m_iA), J.angularA) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(J.linearB, MB), J.linearB) +
		b3Mul1x3w3x1(b3Mul1x3w3x3(J.angularB, m_iB), J.angularB);

	r32 mass = kMass != 0.0f ? 1.0f / kMass : 0.0f;

	r32 lambda = -mass * C;

	xA += m_mA * lambda * J.linearA;
	qA += b3Derivate(qA, b3Mul(m_iA, lambda * J.angularA));
	xB += m_mB * lambda * J.linearB;
	qB += b3Derivate(qB, b3Mul(m_iB, lambda * J.angularB));

	data->positions[m_indexA].x = xA;
	data->positions[m_indexA].q = qA;
	data->positions[m_indexB].x = xB;
	data->positions[m_indexB].q = qB;
	
	return linearError <= B3_LINEAR_SLOP;
}

void b3DistanceJoint::Draw(const b3Draw* draw) const 
{
	b3Color red = draw->m_red;
	b3Color green = draw->m_green;
	b3Color blue = draw->m_blue;

	b3Vec3 worldAnchorA = b3Mul(m_bodyA->GetTransform(), m_localAnchorA);
	b3Vec3 worldAnchorB = b3Mul(m_bodyB->GetTransform(), m_localAnchorB);

	draw->DrawPoint(worldAnchorA, red);
	draw->DrawPoint(worldAnchorB, green);
	draw->DrawLine(worldAnchorA, worldAnchorB, blue);
}
