//--------------------------------------------------------------------------------------------------
/*
	@file		b3Joint.h

	@author		Irlan Robson
	@version	0.1
	@date		20/02/2016

	Copyright(C) 2016 by I. Robson. All rights reserved.
*/
//--------------------------------------------------------------------------------------------------

#ifndef _B3_JOINT_H_
#define _B3_JOINT_H_

#include "..\..\Common\Math\b3Vec3.h"
#include "..\..\Common\Math\b3Mat33.h"
#include "..\..\Common\Math\b3Transform.h"

class b3Draw;
class b3Body;
class b3Joint;
struct b3SolverData;

enum b3JointType
{
	e_distanceJoint,
};

enum b3LimitState
{
	e_inactiveLimit,
	e_atLowerLimit,
	e_atUpperLimit,
	e_equalLimits
};

struct b3Jacobian
{
	b3Vec3 linearA;
	b3Vec3 linearB;
	b3Vec3 angularA;
	b3Vec3 angularB;
};

struct b3JointEdge 
{
	b3Joint* joint;
	b3Body* other;
	b3JointEdge* prev;
	b3JointEdge* next;
};

struct b3JointDef
{
	b3JointDef()
	{
		type = e_unknownJoint;
		bodyA = nullptr;
		bodyB = nullptr;
		userData = nullptr;
	}

	b3JointType type;
	b3Body* bodyA;
	b3Body* bodyB;
	void* userData;
};

class b3Joint 
{
public :
	// Get the joint type.
	b3JointType GetType() const { return m_type; }

	// Get the first body connected to the joint.
	const b3Body* GetBodyA() const;
	b3Body* GetBodyA();

	// Set the body to be connected to the joint as the first body.
	virtual void SetBodyA(b3Body* bodyA);

	// Get the second body connected to the joint.
	const b3Body* GetBodyB() const;
	b3Body* GetBodyB();

	// Set the body to be connected to the joint as the second body.
	virtual void SetBodyB(b3Body* bodyB);

	// Get the user specific data associated with the joint.
	void* GetUserData();
	const void* GetUserData() const;

	// Set the user data to be associated with the joint.
	void SetUserData(void* data);

	// Draw the joint for the user.
	virtual void Draw(const b3Draw* draw) const = 0;
protected :
	friend class b3Body;
	friend class b3World;
	friend class b3JointGraph;
	friend class b3JointSolver;

	b3Joint() {	}
	virtual ~b3Joint() { }
	
	virtual void InitializeConstraints(const b3SolverData* data) = 0;
	virtual void WarmStart(const b3SolverData* data) = 0;
	virtual void SolveVelocityConstraints(const b3SolverData* data) = 0;
	virtual bool SolvePositionConstraints(const b3SolverData* data) = 0;

	enum b3JointFlags 
	{
		e_islandFlag = 0x0001,
		e_activeFlag = 0x0002,
		e_collideLinkedFlag = 0x0004,
	};
	
	b3JointType m_type;
	u32 m_flags;
	b3Body* m_bodyA;
	b3Body* m_bodyB;
	void* m_userData;

	// Joint graph data.
	b3JointEdge m_nodeA;
	b3JointEdge m_nodeB;

	b3Joint* m_prev;
	b3Joint* m_next;
};

inline const b3Body* b3Joint::GetBodyA() const
{
	return m_bodyA;
}

inline b3Body* b3Joint::GetBodyA()
{
	return m_bodyA;
}

inline void b3Joint::SetBodyA(b3Body* bodyA) 
{
	m_bodyA = bodyA;
}

inline b3Body* b3Joint::GetBodyB() 
{
	return m_bodyB;
}

inline const b3Body* b3Joint::GetBodyB() const 
{
	return m_bodyB;
}

inline void b3Joint::SetBodyB(b3Body* bodyB) 
{
	m_bodyB = bodyB;
}

inline void b3Joint::SetUserData(void* data) 
{
	m_userData = data;
}

inline void* b3Joint::GetUserData() 
{
	return m_userData;
}

inline const void* b3Joint::GetUserData() const 
{
	return m_userData;
}

#endif