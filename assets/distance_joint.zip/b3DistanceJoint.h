//--------------------------------------------------------------------------------------------------
/*
	@file		b3DistanceJoint.h

	@author		Irlan Robson
	@version	0.1
	@date		20/02/2016

	Copyright(C) 2016 by I. Robson. All rights reserved.
*/
//--------------------------------------------------------------------------------------------------

#ifndef _B3_DISTANCE_JOINT_H_
#define _B3_DISTANCE_JOINT_H_

#include "b3Joint.h"

struct b3DistanceJointDef : public b3JointDef 
{
	b3DistanceJointDef() 
	{
		type = e_distanceJoint;
		localAnchorA.SetZero();
		localAnchorB.SetZero();
		length = 0.0f;
	}

	b3Vec3 localAnchorA;
	b3Vec3 localAnchorB;
	r32 length;
};

class b3DistanceJoint : public b3Joint 
{
public :	
	// Get the local anchor point in the local space of the first body.
	const b3Vec3& GetLocalAnchorA() const;

	// Get the local anchor point in the local space of the second body.
	const b3Vec3& GetLocalAnchorB() const;

	// Draw the joint information.
	virtual void Draw(const b3Draw* draw) const;
protected :
	friend class b3JointGraph;
	friend class b3JointSolver;

	b3DistanceJoint(const b3DistanceJointDef* def);

	virtual void InitializeConstraints(const b3SolverData* data);
	virtual void WarmStart(const b3SolverData* data);
	virtual void SolveVelocityConstraints(const b3SolverData* data);
	virtual bool SolvePositionConstraints(const b3SolverData* data);

	// The two anchor points on the local space of each body.
	b3Vec3 m_localAnchorA;
	b3Vec3 m_localAnchorB;
	// How much the anchor points must be separated by.
	r32 m_length;

	// Temporary data copied from the joint solver.
	// to avoid cache misses.
	u32 m_indexA;
	u32 m_indexB;
	r32 m_mA;
	r32 m_mB;
	b3Mat33 m_iA;
	b3Mat33 m_iB;

	// Velocity constraint data.
	b3Jacobian m_J;
	r32 m_mass;
	r32 m_impulse;
	
	// Position constraint data.
	b3Vec3 m_localCenterA;
	b3Vec3 m_localCenterB;
};

inline const b3Vec3& b3DistanceJoint::GetLocalAnchorA() const 
{
	return m_localAnchorA;
}

inline const b3Vec3& b3DistanceJoint::GetLocalAnchorB() const 
{
	return m_localAnchorB;
}

#endif